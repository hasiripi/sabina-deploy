import{c as g,u as D,a as N,b as O,d as K,r,f as G,j as e,l as X,X as P,P as B,M as U,N as I,e as H,C as $,B as q}from"./index-2hmLQUwT.js";import{S as V}from"./settings-zQxzWLKu.js";import{H as Y,Q}from"./quote-BTvAe0MN.js";import{C as J}from"./circle-user-EvABrYPo.js";import{B as Z}from"./briefcase-DtmdtAtH.js";import{F as C}from"./folder-open-55JqPjZX.js";import{I as ee}from"./image-CZn_Ja6p.js";import{I as te}from"./inbox-C00p_ue7.js";import{U as A}from"./users-DAcyEME_.js";import{S as T}from"./send-BZio-2wR.js";import{C as ae}from"./chart-column-CbpybEg0.js";import{A as ne}from"./activity-zM38SZB5.js";import{E as ie}from"./external-link-BBIaCn7l.js";/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const re=[["path",{d:"m15.477 12.89 1.515 8.526a.5.5 0 0 1-.81.47l-3.58-2.687a1 1 0 0 0-1.197 0l-3.586 2.686a.5.5 0 0 1-.81-.469l1.514-8.526",key:"1yiouv"}],["circle",{cx:"12",cy:"8",r:"6",key:"1vp47v"}]],oe=g("award",re);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const le=[["circle",{cx:"12",cy:"12",r:"1",key:"41hilf"}],["circle",{cx:"19",cy:"12",r:"1",key:"1wjl8i"}],["circle",{cx:"5",cy:"12",r:"1",key:"1pcz8c"}]],se=g("ellipsis",le);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const de=[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]],z=g("layout-dashboard",de);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ce=[["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}],["polyline",{points:"16 17 21 12 16 7",key:"1gabdz"}],["line",{x1:"21",x2:"9",y1:"12",y2:"12",key:"1uyos4"}]],pe=g("log-out",ce);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const ge=[["path",{d:"M15 18h-5",key:"95g1m2"}],["path",{d:"M18 14h-8",key:"sponae"}],["path",{d:"M4 22h16a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2H8a2 2 0 0 0-2 2v16a2 2 0 0 1-4 0v-9a2 2 0 0 1 2-2h2",key:"39pd36"}],["rect",{width:"8",height:"4",x:"10",y:"6",rx:"1",key:"aywv1n"}]],me=g("newspaper",ge);/**
 * @license lucide-react v0.487.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const he=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8",key:"1357e3"}],["path",{d:"M3 3v5h5",key:"1xhq8a"}]],ue=g("rotate-ccw",he),fe=[{key:"main",label:"ANA"},{key:"content",label:"ICERIK"},{key:"communication",label:"ILETISIM"},{key:"system",label:"SISTEM"}],E=[{label:"Kontrol Paneli",path:"/admin",icon:z,group:"main"},{label:"Genel Ayarlar",path:"/admin/genel-ayarlar",icon:V,group:"main",roles:["admin"]},{label:"Ana Sayfa",path:"/admin/ana-sayfa",icon:Y,group:"content",roles:["admin"]},{label:"Hakkimizda",path:"/admin/hakkimizda",icon:J,group:"content",roles:["admin"]},{label:"Hizmetler",path:"/admin/hizmetler",icon:Z,group:"content",roles:["admin"]},{label:"Projeler",path:"/admin/projeler",icon:C,group:"content"},{label:"Markalar",path:"/admin/markalar",icon:oe,group:"content",roles:["admin"]},{label:"Referanslar",path:"/admin/referanslar",icon:Q,group:"content",roles:["admin"]},{label:"Basin & Fuarlar",path:"/admin/basin",icon:me,group:"content",roles:["admin"]},{label:"Blog",path:"/admin/blog",icon:B,group:"content"},{label:"Medya Kit",path:"/admin/medya-kit",icon:ee,group:"content",roles:["admin"]},{label:"Basvurular",path:"/admin/basvurular",icon:te,badgeKey:"unread_inquiries",group:"communication"},{label:"CRM Rehber",path:"/admin/crm",icon:A,group:"communication"},{label:"Dahili Mesajlar",path:"/admin/dahili-mesajlar",icon:T,badgeKey:"unread_internal",group:"communication"},{label:"Newsletter",path:"/admin/newsletter",icon:U,group:"communication",roles:["admin"]},{label:"Analitik & SEO",path:"/admin/analitik",icon:ae,group:"system",roles:["admin"]},{label:"Aktivite Log",path:"/admin/aktivite-log",icon:ne,group:"system",roles:["admin"]},{label:"Kullanici Yonetimi",path:"/admin/kullanici-yonetimi",icon:A,badgeKey:"pending_users",group:"system",roles:["admin"]}],xe=[{label:"Panel",path:"/admin",icon:z,group:"main"},{label:"Projeler",path:"/admin/projeler",icon:C,group:"content"},{label:"Blog",path:"/admin/blog",icon:B,group:"content"},{label:"Mesajlar",path:"/admin/dahili-mesajlar",icon:T,badgeKey:"unread_internal",group:"communication"}];function be(f){return E.find(x=>x.path===f)?.label||"Kontrol Paneli"}function Me({children:f}){const{admin:d,logout:x}=D(),{canUndo:M,lastAction:j,undo:R,isUndoing:c}=N(),v=O(),h=K(),[u,m]=r.useState(!1),[o,F]=r.useState({}),[a,S]=r.useState(typeof window<"u"&&window.innerWidth>=1024);r.useEffect(()=>{const t=window.matchMedia("(min-width: 1024px)"),i=s=>S(s.matches);return t.addEventListener("change",i),S(t.matches),()=>t.removeEventListener("change",i)},[]);const b=r.useCallback(async()=>{try{const t=await G();F({unread_messages:t.messages?.unread||0,unread_inquiries:t.inquiries?.unread||0,pending_users:t.pending_users||0,unread_internal:t.unread_internal||0})}catch{}},[]);r.useEffect(()=>{b();const t=setInterval(b,6e4);return()=>clearInterval(t)},[b]),r.useEffect(()=>{m(!1)},[h.pathname]),r.useEffect(()=>(u&&!a?document.body.style.overflow="hidden":document.body.style.overflow="",()=>{document.body.style.overflow=""}),[u,a]);const W=()=>{x(),v("/admin/login")},y=(o.unread_messages||0)+(o.unread_inquiries||0)+(o.pending_users||0)+(o.unread_internal||0),L=a||u,l=d?.role||"admin",k=l==="superadmin",_=d?.permissions||[];return e.jsxs("div",{className:"min-h-screen bg-[#E9E6DE]",style:{display:"flex"},children:[e.jsx("style",{children:`
        /* Undo spinner */
        @keyframes spin {
          from { transform: rotate(0deg); }
          to   { transform: rotate(-360deg); }
        }
        /* Sidebar slide-in animation */
        @keyframes sidebarSlideIn {
          from { transform: translateX(-100%); opacity: 0; }
          to   { transform: translateX(0);     opacity: 1; }
        }
        @keyframes sidebarSlideOut {
          from { transform: translateX(0);     opacity: 1; }
          to   { transform: translateX(-100%); opacity: 0; }
        }

        @media (max-width: 1023px) {
          /* ===== PAGE HEADERS: wrap title + action buttons ===== */
          .admin-page .flex.items-center.justify-between,
          .admin-page .flex.justify-between.items-center,
          .admin-page .flex.justify-between.items-end,
          .admin-page .flex.items-end.justify-between {
            flex-wrap: wrap !important;
            gap: 10px !important;
          }

          /* ===== GRIDS: force single column on mobile ===== */
          .admin-page .grid.grid-cols-3,
          .admin-page .grid.grid-cols-4 {
            grid-template-columns: 1fr !important;
          }
          .admin-page .grid.grid-cols-2 {
            grid-template-columns: repeat(2, 1fr) !important;
          }

          /* ===== SM: / MD: / LG: responsive prefix overrides ===== */
          .admin-page .sm\\:grid-cols-2 { grid-template-columns: 1fr !important; }
          .admin-page .sm\\:grid-cols-3 { grid-template-columns: 1fr !important; }
          .admin-page .sm\\:grid-cols-4 { grid-template-columns: repeat(2, 1fr) !important; }
          .admin-page .md\\:grid-cols-2 { grid-template-columns: 1fr !important; }
          .admin-page .md\\:grid-cols-3 { grid-template-columns: 1fr !important; }
          .admin-page .lg\\:grid-cols-3 { grid-template-columns: 1fr !important; }
          .admin-page .lg\\:grid-cols-4 { grid-template-columns: repeat(2, 1fr) !important; }

          /* ===== TABLES: horizontal scroll + compact ===== */
          .admin-page table {
            font-size: 13px !important;
          }
          .admin-page .overflow-x-auto {
            -webkit-overflow-scrolling: touch;
          }
          .admin-page table th,
          .admin-page table td {
            padding: 8px 6px !important;
            white-space: nowrap;
          }
          .admin-page table .hidden.sm\\:table-cell,
          .admin-page table .hidden.md\\:table-cell,
          .admin-page table .hidden.lg\\:table-cell {
            display: none !important;
          }

          /* ===== TAB NAVIGATION: horizontal scroll ===== */
          .admin-page [role="tablist"],
          .admin-page .flex.border-b {
            overflow-x: auto !important;
            -webkit-overflow-scrolling: touch;
            flex-wrap: nowrap !important;
            scrollbar-width: none;
          }
          .admin-page [role="tablist"]::-webkit-scrollbar,
          .admin-page .flex.border-b::-webkit-scrollbar {
            display: none;
          }
          .admin-page [role="tab"],
          .admin-page .flex.border-b > button {
            white-space: nowrap !important;
            flex-shrink: 0 !important;
          }

          /* ===== DIALOGS: full width on mobile ===== */
          .admin-page [role="dialog"],
          .admin-page .fixed.inset-0 > div > div {
            max-width: calc(100vw - 24px) !important;
            margin-left: 12px !important;
            margin-right: 12px !important;
          }
          .admin-page [role="dialog"] .sm\\:max-w-lg,
          .admin-page [role="dialog"] .sm\\:max-w-2xl,
          .admin-page [role="dialog"] .sm\\:max-w-3xl {
            max-width: calc(100vw - 24px) !important;
          }
          .admin-page [role="dialog"] .grid.grid-cols-2,
          .admin-page [role="dialog"] .grid.grid-cols-3 {
            grid-template-columns: 1fr !important;
          }

          /* ===== BUTTONS: smaller + wrap ===== */
          .admin-page .gap-2 > button,
          .admin-page .gap-3 > button {
            font-size: 12px !important;
          }

          /* ===== TEXT OVERFLOW FIX ===== */
          .admin-page h2, .admin-page h3 {
            word-break: break-word;
          }
          .admin-page .truncate {
            max-width: 150px;
          }

          /* ===== STAT CARDS: keep 2-col grid compact ===== */
          .admin-page .grid.grid-cols-2 > div {
            min-width: 0;
          }
        }

        /* Extra small screens (<400px) */
        @media (max-width: 400px) {
          .admin-page .grid.grid-cols-2 {
            grid-template-columns: 1fr !important;
          }
        }
      `}),!a&&e.jsx("div",{className:`transition-all duration-300 ${u?"bg-black/20 backdrop-blur-sm opacity-100 pointer-events-auto":"opacity-0 pointer-events-none"}`,style:{position:"fixed",inset:0,zIndex:40},onClick:()=>m(!1)}),e.jsxs("aside",{style:{position:"fixed",top:0,left:0,bottom:0,zIndex:50,width:280,height:"100vh",display:"flex",flexDirection:"column",transform:L?"translateX(0)":"translateX(-100%)",transition:"transform 0.32s cubic-bezier(0.32, 0.72, 0, 1)",background:"rgba(255,255,255,0.35)",backdropFilter:"blur(40px) saturate(180%)",WebkitBackdropFilter:"blur(40px) saturate(180%)",borderRight:"1px solid rgba(255,255,255,0.4)",boxShadow:"4px 0 24px rgba(0,0,0,0.03)"},children:[e.jsxs("div",{style:{height:72,display:"flex",alignItems:"center",justifyContent:"space-between",padding:"0 20px",borderBottom:"1px solid rgba(187,163,149,0.1)",flexShrink:0},children:[e.jsx("div",{style:{display:"flex",alignItems:"center",gap:12},children:e.jsx("img",{src:X,alt:"Logo",style:{height:47,width:"auto",objectFit:"contain"}})}),!a&&e.jsx("button",{onClick:()=>m(!1),style:{width:30,height:30,borderRadius:8,background:"rgba(0,0,0,0.04)",border:"none",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#1F1F1F"},children:e.jsx(P,{style:{width:16,height:16}})})]}),e.jsx("div",{style:{padding:"12px 20px 4px 20px",flexShrink:0},children:e.jsx("span",{style:{fontVariant:"small-caps",letterSpacing:"0.2em",color:"#BBA395",fontSize:9,fontWeight:500},children:"Design Office"})}),e.jsx("div",{style:{flex:1,overflowY:"auto",overflowX:"hidden",padding:"8px 12px"},children:e.jsx("nav",{style:{display:"flex",flexDirection:"column",gap:14},children:fe.map((t,i)=>{const s=E.filter(n=>n.group!==t.key?!1:k?!0:l==="admin"?!n.roles||n.roles.includes(l):_.includes(n.path));return s.length===0?null:e.jsxs("div",{children:[i>0&&e.jsx("div",{style:{height:1,background:"linear-gradient(to right, transparent, rgba(187,163,149,0.2), transparent)",margin:"0 8px 10px 8px"}}),e.jsx("p",{style:{textTransform:"uppercase",letterSpacing:"0.15em",fontSize:10,color:"#BBA395",fontWeight:600,padding:"0 14px",marginBottom:6},children:t.label}),e.jsx("div",{style:{display:"flex",flexDirection:"column",gap:3},children:s.map(n=>e.jsx(I,{to:n.path,end:n.path==="/admin",style:{textDecoration:"none"},children:({isActive:p})=>e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,padding:"10px 14px",borderRadius:14,fontSize:13,fontWeight:p?500:400,color:p?"#620909":"#4A4A4A",background:p?"rgba(98,9,9,0.08)":"transparent",position:"relative",transition:"background 0.15s ease, color 0.15s ease",cursor:"pointer"},onMouseEnter:w=>{p||(w.currentTarget.style.background="rgba(0,0,0,0.03)")},onMouseLeave:w=>{p||(w.currentTarget.style.background="transparent")},children:[p&&e.jsx("div",{style:{position:"absolute",left:4,top:"50%",transform:"translateY(-50%)",width:3,height:18,borderRadius:3,background:"#620909"}}),e.jsx(n.icon,{style:{width:18,height:18,strokeWidth:1.8,flexShrink:0}}),e.jsx("span",{style:{flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:n.label}),n.badgeKey&&o[n.badgeKey]>0&&e.jsx("span",{style:{background:"#620909",color:"#fff",fontSize:10,fontWeight:600,padding:"1px 6px",borderRadius:10,minWidth:18,height:18,display:"flex",alignItems:"center",justifyContent:"center",lineHeight:1},children:o[n.badgeKey]})]})},n.path))})]},t.key)})})}),e.jsx("div",{style:{padding:"12px 14px",borderTop:"1px solid rgba(187,163,149,0.12)",flexShrink:0},children:e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,padding:"10px 12px",borderRadius:14,background:"rgba(255,255,255,0.45)",border:"1px solid rgba(255,255,255,0.5)",backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)"},children:[e.jsx("div",{style:{width:32,height:32,borderRadius:10,background:"linear-gradient(135deg, #620909, #8B1A1A)",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:12,fontWeight:600,flexShrink:0},children:d?.name?.charAt(0)?.toUpperCase()||"A"}),e.jsxs("div",{style:{flex:1,minWidth:0},children:[e.jsx("p",{style:{fontSize:12,fontWeight:500,color:"#1F1F1F",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",margin:0,lineHeight:1.3},children:d?.email||"admin"}),e.jsx("span",{style:{display:"inline-block",marginTop:3,fontSize:9,fontWeight:600,textTransform:"uppercase",letterSpacing:"0.08em",padding:"2px 6px",borderRadius:6,background:k||l==="admin"?"rgba(34,197,94,0.12)":"rgba(59,130,246,0.12)",color:k||l==="admin"?"#16a34a":"#2563eb"},children:l==="admin"||l==="superadmin"?"Admin":"Asistan"})]}),e.jsx("button",{onClick:W,title:"Cikis Yap",style:{width:30,height:30,borderRadius:8,background:"rgba(0,0,0,0.03)",border:"none",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#999",flexShrink:0,transition:"color 0.15s ease, background 0.15s ease"},onMouseEnter:t=>{t.currentTarget.style.color="#dc2626",t.currentTarget.style.background="rgba(220,38,38,0.08)"},onMouseLeave:t=>{t.currentTarget.style.color="#999",t.currentTarget.style.background="rgba(0,0,0,0.03)"},children:e.jsx(pe,{style:{width:15,height:15}})})]})})]}),e.jsxs("div",{className:"flex-1 flex flex-col min-h-screen min-w-0",style:{marginLeft:a?280:0},children:[e.jsxs("header",{style:{position:"sticky",top:0,zIndex:30,background:"rgba(255,255,255,0.4)",backdropFilter:"blur(20px)",WebkitBackdropFilter:"blur(20px)",borderBottom:"1px solid rgba(187,163,149,0.1)",padding:a?"0 32px":"0 12px",height:a?64:52,display:"flex",alignItems:"center",justifyContent:"space-between",gap:8},children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:10,minWidth:0,flex:1},children:[!a&&e.jsx("button",{onClick:()=>m(!0),style:{width:36,height:36,borderRadius:10,background:"rgba(255,255,255,0.6)",border:"1px solid rgba(255,255,255,0.4)",display:"flex",alignItems:"center",justifyContent:"center",backdropFilter:"blur(8px)",WebkitBackdropFilter:"blur(8px)",cursor:"pointer",flexShrink:0},children:e.jsx(H,{style:{width:16,height:16,color:"#1F1F1F"}})}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6,minWidth:0},children:[a&&e.jsxs(e.Fragment,{children:[e.jsx("span",{onClick:()=>v("/admin"),style:{color:"#BBA395",fontSize:13,cursor:"pointer",transition:"color 0.15s"},onMouseEnter:t=>{t.currentTarget.style.color="#620909"},onMouseLeave:t=>{t.currentTarget.style.color="#BBA395"},children:"Yonetim"}),e.jsx($,{style:{width:12,height:12,color:"#BBA395",flexShrink:0}})]}),e.jsx("span",{style:{fontFamily:"'Noto Serif', Georgia, serif",fontWeight:500,color:"#1F1F1F",fontSize:15,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"},children:be(h.pathname)})]})]}),e.jsxs("div",{style:{display:"flex",alignItems:"center",gap:6,flexShrink:0},children:[M&&e.jsxs("button",{onClick:R,disabled:c,title:j?`Geri al: ${j.label}`:"Geri Al",style:{display:"flex",alignItems:"center",gap:5,padding:"6px 12px",borderRadius:10,background:"rgba(98,9,9,0.08)",border:"1px solid rgba(98,9,9,0.15)",color:"#620909",fontSize:12,fontWeight:500,cursor:c?"default":"pointer",opacity:c?.6:1,transition:"all 0.2s ease"},onMouseEnter:t=>{c||(t.currentTarget.style.background="rgba(98,9,9,0.14)")},onMouseLeave:t=>{t.currentTarget.style.background="rgba(98,9,9,0.08)"},children:[e.jsx(ue,{style:{width:13,height:13,animation:c?"spin 1s linear infinite":"none"}}),a&&e.jsx("span",{children:c?"Geri aliniyor...":"Geri Al"})]}),e.jsxs("a",{href:"/",target:"_blank",rel:"noopener noreferrer",style:{display:"flex",alignItems:"center",gap:5,fontSize:12,color:"#BBA395",padding:"6px 10px",borderRadius:8,textDecoration:"none",transition:"color 0.15s ease"},onMouseEnter:t=>{t.currentTarget.style.color="#8A7565"},onMouseLeave:t=>{t.currentTarget.style.color="#BBA395"},children:[e.jsx(ie,{style:{width:13,height:13}}),a&&e.jsx("span",{children:"Siteyi Goruntule"})]}),e.jsxs("button",{style:{position:"relative",width:34,height:34,borderRadius:10,background:"transparent",border:"none",display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",color:"#BBA395",transition:"color 0.15s ease"},onMouseEnter:t=>{t.currentTarget.style.color="#8A7565"},onMouseLeave:t=>{t.currentTarget.style.color="#BBA395"},children:[e.jsx(q,{style:{width:16,height:16}}),y>0&&e.jsx("span",{style:{position:"absolute",top:4,right:4,width:8,height:8,borderRadius:"50%",background:"#620909",border:"2px solid rgba(255,255,255,0.6)"}})]}),e.jsx("div",{style:{width:32,height:32,borderRadius:"50%",background:"linear-gradient(135deg, #620909, #8B1A1A)",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:12,fontWeight:600,flexShrink:0},children:d?.name?.charAt(0)?.toUpperCase()||"A"})]})]}),e.jsx("main",{className:"admin-page",style:{flex:1,padding:a?32:16,paddingBottom:a?32:96},children:f}),!a&&e.jsx("nav",{style:{position:"fixed",bottom:0,left:0,right:0,zIndex:40},children:e.jsx("div",{style:{background:"rgba(255,255,255,0.4)",backdropFilter:"blur(40px) saturate(180%)",WebkitBackdropFilter:"blur(40px) saturate(180%)",borderTop:"1px solid rgba(255,255,255,0.45)",paddingLeft:8,paddingRight:8,paddingBottom:"env(safe-area-inset-bottom)"},children:e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-around",height:56},children:[xe.map(t=>{const i=t.path==="/admin"?h.pathname==="/admin":h.pathname.startsWith(t.path),s=t.badgeKey&&o[t.badgeKey]||0;return e.jsxs(I,{to:t.path,end:t.path==="/admin",style:{position:"relative",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:2,width:64,height:"100%",textDecoration:"none"},children:[e.jsxs("div",{style:{position:"relative",color:i?"#620909":"rgba(0,0,0,0.3)"},children:[e.jsx(t.icon,{style:{width:20,height:20,strokeWidth:1.8}}),s>0&&e.jsx("span",{style:{position:"absolute",top:-4,right:-6,background:"#620909",color:"#fff",fontSize:8,fontWeight:700,width:14,height:14,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"},children:s})]}),e.jsx("span",{style:{fontSize:10,color:i?"#620909":"rgba(0,0,0,0.3)",fontWeight:i?600:400},children:t.label}),i&&e.jsx("div",{style:{position:"absolute",top:0,left:"50%",transform:"translateX(-50%)",width:32,height:2,background:"#620909",borderRadius:4}})]},t.path)}),e.jsxs("button",{onClick:()=>m(!0),style:{position:"relative",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:2,width:64,height:"100%",background:"none",border:"none",cursor:"pointer"},children:[e.jsx(se,{style:{width:20,height:20,color:"rgba(0,0,0,0.3)",strokeWidth:1.8}}),e.jsx("span",{style:{fontSize:10,color:"rgba(0,0,0,0.3)"},children:"Daha"}),y>0&&e.jsx("span",{style:{position:"absolute",top:6,right:8,background:"#620909",color:"#fff",fontSize:8,fontWeight:700,width:14,height:14,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center"},children:y})]})]})})})]})]})}export{Me as default};
