import{j as s,y as a}from"./index-2hmLQUwT.js";function o({className:e,...t}){return s.jsx("div",{"data-slot":"skeleton",className:a("bg-accent animate-pulse rounded-md",e),...t})}export{o as S};
